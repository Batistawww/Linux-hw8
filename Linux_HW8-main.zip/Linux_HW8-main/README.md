# Урок 8. Запуск веб-приложения из контейнеров

    
##   Задание 1. Установить в виртуальную машину или VDS Docker, настроить набор контейнеров через docker compose по инструкции по ссылке: https://www.digitalocean.com/community/tutorials/how-to-install-wordpress-with-docker-compose-ru. Часть с настройкой certbot и HTTPS опустить, если у вас нет настоящего домена и белого IP.

### Скриншоты работы Worpress

![alt Начальнвя страница](Screenshot_1.png)  

![alt Начальнвя страница](https://github.com/Ask1509/Linux_HW8/blob/d4fa84bbd9e1555d5f1a1f2d6130d2e263687b3f/Screenshot_2.png)  

![alt Начальнвя страница](Screenshot_3.png)  
